import 'package:flutter/material.dart';

Map<int, Color> color = {
  50: Color.fromRGBO(54, 12, 223, .5),
  100: Color.fromRGBO(54, 12, 223, 1),
};

MaterialColor alphacolor = MaterialColor(0xFF360CDF, color);
