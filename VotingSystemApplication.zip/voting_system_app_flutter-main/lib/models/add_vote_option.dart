class CandidateModel {
  String imgUrl;
  String name;
  String description;

  CandidateModel({this.imgUrl, this.name, this.description});
}
